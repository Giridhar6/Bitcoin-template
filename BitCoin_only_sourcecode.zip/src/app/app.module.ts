import { MediaMatcher } from '@angular/cdk/layout';
import { MaterialModule } from './modules/material/material.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { RoutingModule } from './modules/routing/routing.module';
import { CustomTabDirective } from './directives/custom-tab.directive';
import { CommonComponent } from './components/common/common.component';
import { AssetTranstionComponent } from './components/asset-transtion/asset-transtion.component';
import { NvD3Module } from 'ng2-nvd3';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CustomTabDirective,
    CommonComponent,
    AssetTranstionComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MaterialModule, // Defines angular material components
    RoutingModule,  // Defines routing configurations
    NvD3Module
  ],
  providers: [
    MediaMatcher // CDK provider to detect mobile, desktop etc.
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
