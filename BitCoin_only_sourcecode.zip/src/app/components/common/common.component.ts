import { MediaMatcher } from '@angular/cdk/layout';
import { MediaComponent } from './../media-component';
import { Component, OnInit, ChangeDetectorRef, ElementRef, ViewChild, HostListener } from '@angular/core';

@Component({
  selector: 'app-common',
  templateUrl: './common.component.html',
  styleUrls: ['./common.component.css']
})
export class CommonComponent extends MediaComponent implements OnInit {

  @ViewChild('menuContainer') menuContainer: ElementRef;
  @ViewChild('transactionAmountLabel') amountlabel: ElementRef;
  menuHeight: string;
  btcVal = 0;

  constructor(private changeDetectorRef: ChangeDetectorRef, private mediamatcher: MediaMatcher) {
    super(changeDetectorRef, mediamatcher);
   }

  ngOnInit() {
    this.menuHeight = window.getComputedStyle(this.menuContainer.nativeElement).height;
    this.amountlabel.nativeElement.style.float = 'right';
    this.amountlabel.nativeElement.style.direction = 'ltr';
    console.log(this.amountlabel);
  }

  @HostListener('window:resize', ['$event']) changeMarginTop(event) {
    this.menuHeight = window.getComputedStyle(this.menuContainer.nativeElement).height;
  }

}
