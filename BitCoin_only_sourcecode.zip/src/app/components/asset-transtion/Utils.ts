export class Utils {
    screenHeight: any;
    screenWidth: any;
    constructor() {
      this.screenHeight = window.screen.height ;
      this.screenWidth = window.screen.width ;
    //   console.log('Screen Height =', this.screenHeight);
    //   console.log('Screen Width =', this.screenWidth);
    }
}
