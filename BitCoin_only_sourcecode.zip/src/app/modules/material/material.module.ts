import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  MatToolbarModule,
  MatIconModule,
  MatButtonModule,
  MatSidenavModule,
  MatListModule,
  MatFormFieldModule,
  MatTabsModule,
  MatGridListModule,
  MatProgressBarModule,
  MatInputModule
 } from '@angular/material';

// MaterialModule defines Angular material components that are used inside app
@NgModule({
  imports: [
    CommonModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatListModule,
    MatFormFieldModule,
    MatTabsModule,
    MatGridListModule,
    MatProgressBarModule,
    MatInputModule
  ],
  exports: [
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatListModule,
    MatFormFieldModule,
    MatTabsModule,
    MatGridListModule,
    MatProgressBarModule,
    MatInputModule
  ],
  declarations: []
})
export class MaterialModule { }
