import { Component } from '@angular/core';

// AppComponent is the bootstrapped component of the app which loads all other components
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
}
