import { CustomTabDirective } from './custom-tab.directive';

describe('CustomTabDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomTabDirective();
    expect(directive).toBeTruthy();
  });
});
